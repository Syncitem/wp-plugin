Plugin boilerplate
==================

Build your custom plugin using this Themosis framework plugin boilerplate.

The plugin is configured to work on a Themosis framework like environment only.

Easily extends WordPress. Build administration features, define front-end custom routes,
add custom API endpoints,... all from the plugin.

[Read the documentation](https://framework.themosis.com/docs/2.0/plugin/) on the Themosis framework website and start developing your own plugin.
