<?php

use Themosis\Support\Facades\Route;

/**
 * Plugin custom routes.
 */
